<?php
/* This class must be included in another file and included later so we don't get an error about HeadwayBlockAPI class not existing. */

class HeadwayExampleBlock extends HeadwayBlockAPI {
	
	
	public $id = 'big-link-block';
	
	public $name = 'Big Link Block';
	
	public $options_class = 'BigLinkBlockOptions';

	public $description = 'A custom text block with an anchor overlay which serves as one big button.';
		
	/**
	 * This function will insert dynamic CSS into real CSS files thus negating the need for nasty inline CSS (whether in a <style> element or the style attribute)
	 *
         * REMOVE THIS METHOD IF NOT USING IT
         **/
	function dynamic_css($block_id) {
		
		return;
		
	}


	/**
	 * Elements that you wish to be stylable with the Design Editor need to be registered in this function.
	 *
         * REMOVE THIS METHOD IF NOT USING IT
         **/
	function setup_elements() {

		$this->register_block_element(array(
			'id' => 'overlay', 
			'name' => 'Overlay', 
			'selector' => '.big-link-overlay',
			'properties' => array('background', 'borders', 'padding', 'rounded-corners', 'box-shadow'),
			'states' => array(
				'Selected' => '.big-link-overlay.selected', 
				'Hover' => '.big-link-overlay:hover', 
				'Clicked' => '.big-link-overlay:active'
			)
		));
		
		$this->register_block_element(array(
			'id' => 'text', 
			'name' => 'Text', 
			'selector' => '.big-link-text',
			'properties' => array('font', 'text-shadow')
			)
		));
		
	}
	

	/** 
	 * Anything in here will be displayed when the block is being displayed.
	 **/
	function content($block) {
		
		//The third argument in the following function is the default that will be returned if the setting is not present in the database
		$example_input_value = parent::get_setting($block, 'big_link_content', null); 
		
		if ( $example_input_value == null ) {
			
			echo big_link_content;
						
		}
		
	}
	
}